//
//  WebGenretorApp2App.swift
//  WebGenretorApp2
//
//  Created by LIPL-227 on 21/03/22.
//

import SwiftUI

@main
struct WebGenretorApp2App: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
