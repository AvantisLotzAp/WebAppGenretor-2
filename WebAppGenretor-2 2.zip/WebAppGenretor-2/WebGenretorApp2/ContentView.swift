//
//  ContentView.swift
//  WebGenretorApp2
//
//  Created by LIPL-227 on 21/03/22.
//

import SwiftUI
import WebKit
import Combine
 

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}

struct ContentView: View {
     
    @State private var back_disabled = true
    @ObservedObject var viewModel = WebViewModel()
    var _webView = WKWebView()
    
    var body: some View {
        let webView = SwiftUIWebView(viewModel: viewModel, webView: _webView )
        //Pass the url to the SafariWebView struct.
        VStack{
           
            HStack{
                Button(action: {
                    webView.goBack()
                }) {
                    Text("Back")
                }.padding([.top, .leading]  , 10).disabled(!viewModel.canGoBack)
                Spacer()
                Button(action: {
                    webView.goHome()
                   // viewWeb.ba
                }) {
                    Text("Home")
                }.padding([.top, .leading]  , 5)
                Spacer()
                Button(action: {
                    webView.goForward()
                    
                }) {
                    Text("Forword")
                }.padding([.top, .trailing] , 10).disabled(!viewModel.canGoForward)
            
            }
            webView
            
        }
        
        
    }
}
 

class WebViewModel: ObservableObject {
    
    @Published var link   = "https://www.apple.com"
    @Published var didFinishLoading: Bool = false
    @Published var pageTitle = "TITLE"
    
    @Published var canGoBack : Bool = false
    @Published var canGoForward  : Bool = false
    
     
    
    
}

struct SwiftUIWebView: NSViewRepresentable {
    
    public typealias NSViewType = WKWebView
    @ObservedObject var viewModel : WebViewModel
    var _webView = WKWebView()
    
    init(viewModel:WebViewModel , webView : WKWebView  ){
        self._webView = webView
        self.viewModel = viewModel
        
    }

    
    
    public func makeNSView(context: NSViewRepresentableContext<SwiftUIWebView>) -> WKWebView {
        _webView.navigationDelegate = context.coordinator
     //   webView.uiDelegate = context.coordinator
        _webView.load(URLRequest(url: URL(string: viewModel.link)!))
        return _webView
    }

    public func updateNSView(_ nsView: WKWebView, context: NSViewRepresentableContext<SwiftUIWebView>) { }

    public func makeCoordinator() -> Coordinator {
        return Coordinator(viewModel)
    }
    
    class Coordinator: NSObject, WKNavigationDelegate {
        private var viewModel: WebViewModel

        init(_ viewModel: WebViewModel) {
           //Initialise the WebViewModel
           self.viewModel = viewModel
        }
        
      //  public func webView(_: WKWebView, didFail: WKNavigation!, withError: Error) { }
        public func webView(
            _ webView: WKWebView,
            didFail navigation: WKNavigation!,
            withError error: Error
        ) {
            self.viewModel.didFinishLoading = false
            self.viewModel.canGoBack = webView.canGoBack
            self.viewModel.canGoForward = webView.canGoForward
            
        }

        public func webView(_ webView: WKWebView, didFinish navigation: WKNavigation!) {
            viewModel.pageTitle = webView.title!
          //  viewModel.link = webView.url?.absoluteString ?? ""
            viewModel.didFinishLoading = true
            
            self.viewModel.didFinishLoading = false
            self.viewModel.canGoBack = webView.canGoBack
            self.viewModel.canGoForward = webView.canGoForward
        }
        
        
        public func webView(_ webView: WKWebView, didStartProvisionalNavigation navigation: WKNavigation!) {
            
        }

        public func webView(
            _ webView: WKWebView,
            didFailProvisionalNavigation navigation: WKNavigation!,
            withError error: Error
        ) {
            viewModel.didFinishLoading = false
            viewModel.canGoBack = webView.canGoBack
            viewModel.canGoForward = webView.canGoForward
            
        }
        
        
        
        public func webView(_ webView: WKWebView, decidePolicyFor navigationAction: WKNavigationAction, decisionHandler: @escaping (WKNavigationActionPolicy) -> Void) {
            decisionHandler(.allow)
            print(webView.canGoBack)
            print(webView.canGoForward)
            viewModel.canGoBack = webView.canGoBack
            viewModel.canGoForward = webView.canGoForward
        }

    }
    
    public  func webView(_ webView: WKWebView, didCommit navigation: WKNavigation!) {
        viewModel.canGoBack = webView.canGoBack
        viewModel.canGoForward = webView.canGoForward
    }
    
    func goBack(){
        if _webView.canGoBack {
        _webView.goBack()
        }
       }

       func goForward(){
           if _webView.canGoForward {
           _webView.goForward()
           }
       }
       
       func refresh() {
           //_webView.load(URLRequest(url: URL(string: viewModel.link)!))
       }
       
       func goHome() {
          // webView.load(webView.request)
           _webView.load(URLRequest(url: URL(string: viewModel.link)!))
       }

}
